package de.spigotplugins.lobby.data;

import java.util.ArrayList;

public class Data {
	
	public static int FirstJoinPlayers;
	public static boolean Logging;
	public static boolean BungeeCordModus;
	public static boolean EnableJoinMessage;
	public static boolean HealOnJoin;
	public static int HealthScale;
	public static boolean FirstJoinRundruf;
	public static int GameModeOnJoin;
	public static boolean TitleAktiviert;
	public static boolean Hunger;
	public static boolean Schaden;
	public static boolean Abbauen;
	public static boolean GHunger;
	public static boolean GSchaden;
	public static boolean GAbbauen;


}
