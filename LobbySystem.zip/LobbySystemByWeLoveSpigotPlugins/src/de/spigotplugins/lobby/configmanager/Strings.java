package de.spigotplugins.lobby.configmanager;

public class Strings {

	public static String Prefix;
	public static String JoinMessage;
	public static String FirstJoinMessageFormat;
	public static String TitleOneLine;
	public static String TitleTwoLine;
	public static String WeltName;

}
