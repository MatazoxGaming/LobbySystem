package de.spigotplugins.lobby.configmanager;

public class InventoryManager {
	
	public static boolean SetLobbyItems;
	
	public static boolean NavigatorAktiviert;
	public static int NavigatorID;
	public static String NavigatorDisplayName;
	public static int NavigatorInventorySlot;
	public static boolean NavigatorBrauchePermission;
	public static String NavigatorPermission;
	
	public static boolean SpielerVersteckenAktiviert;
	public static int SpielerVersteckenID;
	public static String SpielerVersteckenDisplayName;
	public static int SpielerVersteckenInventorySlot;
	public static boolean SpielerVersteckenBrauchePermission;
	public static String SpielerVersteckenPermission;
	
	public static boolean GadgetsAktiviert;
	public static int GadgetsID;
	public static String GadgetsDisplayName;
	public static int GadgetsInventorySlot;
	public static boolean GadgetsBrauchePermission;
	public static String GadgetsPermission;
	
	public static boolean SchutzschildAktiviert;
	public static int SchutzschildID;
	public static String SchutzschildDisplayName;
	public static int SchutzschildInventorySlot;
	public static boolean SchutzschildBrauchePermission;
	public static String SchutzschildPermission;

	public static boolean NickToolAktiviert;
	public static int NickToolID;
	public static String NickToolDisplayName;
	public static int NickToolInventorySlot;
	public static boolean NickToolBrauchePermission;
	public static String NickToolPermission;
	
	public static boolean FlugstabAktiviert;
	public static int FlugstabID;
	public static String FlugstabDisplayName;
	public static int FlugstabInventorySlot;
	public static boolean FlugstabBrauchePermission;
	public static String FlugstabPermission;
	
	public static boolean SilentLobbyAktiviert;
	public static int SilentLobbyID;
	public static String SilentLobbyDisplayName;
	public static int SilentLobbyInventorySlot;
	public static boolean SilentLobbyBrauchePermission;
	public static String SilentLobbyPermission;
	
	public static boolean LobbySwitcherAktiviert;
	public static int LobbySwitcherID;
	public static String LobbySwitcherDisplayName;
	public static int LobbySwitcherInventorySlot;
	public static boolean LobbySwitcherBrauchePermission;
	public static String LobbySwitcherPermission;
}
