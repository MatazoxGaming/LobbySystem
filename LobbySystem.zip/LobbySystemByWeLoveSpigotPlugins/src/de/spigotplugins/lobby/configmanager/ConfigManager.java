package de.spigotplugins.lobby.configmanager;

public class ConfigManager {

}
